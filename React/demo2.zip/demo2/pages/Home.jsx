import React from 'react';

function Home(){
    return (
        <>
            <h1>Welcome to the Home Page</h1>
            <p>This is the home page of our application.</p>
        </>
    );
}
export default Home;