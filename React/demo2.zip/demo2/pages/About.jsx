import React from 'react';

function About(){
    return (
        <>
            <h1>Welcome to the About Page</h1>
            <p>This is the about page of our application.</p>
        </>
    );
}
export default About;