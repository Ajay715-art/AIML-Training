import React from 'react';

function Contact(){
    return (
        <div>
            <h1>Welcome to the contact Page</h1>
            <p>This is the contact page of our application.</p>
        </div>
    );
}
export default Contact;